import express from "express";
import readline from "readline";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";
// Import RAG (Memori Jangka Panjang LOKAL buatan CEO)
import { addMemory, queryMemory } from "./rag.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const envPath = path.join(__dirname, ".env");

const app = express();
app.use(express.json());

// Load ENV manual jika ada
let config = {};
if (fs.existsSync(envPath)) {
  const envRaw = fs.readFileSync(envPath, "utf8");
  envRaw.split("\n").forEach(line => {
    const parts = line.split("=");
    if (parts.length >= 2) config[parts[0].trim()] = parts.slice(1).join("=").trim();
  });
}

// ── SETUP WIZARD ──
async function runWizard() {
  if (config.PORT && config.API_KEY && config.GEMINI_KEY) return;
  
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  console.log("====================================================");
  console.log("🚀 ELYNISIA PRIVATE SERVER - SETUP WIZARD");
  console.log("====================================================");
  
  const ask = (q) => new Promise(resolve => rl.question(q, resolve));
  
  const port = await ask("1. Masukkan Port untuk Web Server [Default: 3005]: ") || "3005";
  const apiKey = await ask("2. Buat Password Rahasia Server (Digunakan di Telegram '/server connect'): ");
  const geminiKey = await ask("3. Masukkan Gemini API Key kamu (LLM Otak AI): ");
  
  const envContent = `PORT=${port}\nAPI_KEY=${apiKey}\nGEMINI_KEY=${geminiKey}\n`;
  fs.writeFileSync(envPath, envContent, "utf8");
  console.log("✅ Konfigurasi disimpan! Silakan restart server dengan 'npm start'");
  process.exit(0);
}

// ── ENDPOINT API ──
app.post("/v5/chat", async (req, res) => {
  try {
    const { api_key, user_id, username, message, chat_id } = req.body;
    
    const expectedKey = config.API_KEY;
    const authHeader = req.headers.authorization;
    const bearer = authHeader ? authHeader.split(" ")[1] : null;
    
    if (api_key !== expectedKey && bearer !== expectedKey) {
      return res.status(401).json({ error: "Unauthorized: Password Salah." });
    }
    
    console.log(`[Pesan Masuk] Dari ${username}: ${message}`);

    // Inisialisasi LLM
    const llm = new ChatGoogleGenerativeAI({
      apiKey: config.GEMINI_KEY,
      modelName: "gemini-1.5-flash",
      temperature: 0.7
    });

    // Proses RAG (Long-term Memory Lokal)
    let extraContext = "";
    const memories = await queryMemory(user_id, message, 3);
    if (memories.length > 0) {
      extraContext = "\n\n[MEMORI LALU]:\n" + memories.map(m => "- " + m).join("\n");
    }

    const systemPrompt = new SystemMessage(`Kamu adalah asisten AI pribadi bernama Elynisia (Private Mode). Jawablah pertanyaan user dengan santai dan natural.${extraContext}`);
    const humanMsg = new HumanMessage(message);

    const response = await llm.invoke([systemPrompt, humanMsg]);
    
    // Simpan pesan penting ke RAG Memory lokal
    if (message.length > 10) {
      addMemory(user_id, message);
    }

    console.log(`[Balasan AI] -> ${response.text}`);
    return res.json({ success: true, reply: response.text });

  } catch (err) {
    console.error("[Error]", err);
    return res.status(500).json({ error: err.message });
  }
});

async function main() {
  await runWizard();
  app.listen(config.PORT, () => {
    console.log(`\n🌐 Private Server aktif di: http://localhost:${config.PORT}`);
    console.log(`💡 Hubungkan Bot Telegram dengan perintah:`);
    console.log(`/server connect http://<IP_KAMU>:${config.PORT}/v5 ${config.API_KEY} MyPrivatePC\n`);
  });
}
main();